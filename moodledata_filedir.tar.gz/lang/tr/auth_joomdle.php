<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_joomdle', language 'tr', version '4.5'.
 *
 * @package     auth_joomdle
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_joomdledescription'] = 'Bu yöntem, bir kullanıcının Joomla\'da geçerli bir oturumu olup olmadığını bilmek için Joomdle web hizmetlerini kullanır.';
$string['auth_joomla_auto_mailing_lists'] = 'Otomatik posta listeleri';
$string['auth_joomla_auto_mailing_lists_description'] = 'Joomla yapılandırmasını takiben posta listelerini otomatik olarak yönetin';
$string['auth_joomla_connection_method'] = 'Bağlantı yöntemi<br>';
$string['auth_joomla_connection_method_description'] = 'Web Hizmetleri için kullanılacak bağlantı yöntemi<br>';
$string['auth_joomla_forward_events'] = 'Moodle etkinliklerini Joomla\'ya iletme';
$string['auth_joomla_forward_events_description'] = 'Joomla eklentilerinin bunlara tepki verebilmeleri için olayları iletin';
$string['auth_joomla_joomla_auth_token'] = 'Joomdle\'ın Joomla kimlik doğrulama belirteci';
$string['auth_joomla_joomla_auth_token_description'] = 'Joomla\'da Joomdle\'da yapılandırıldığı gibi kimlik doğrulama belirteci';
$string['auth_joomla_joomla_lang'] = 'Joomla varsayılan dili';
$string['auth_joomla_joomla_lang_description'] = 'Joomla varsayılan dil dizesi. Yalnızca Joomla\'da çoklu dil etkinleştirildiğinde gereklidir';
$string['auth_joomla_joomla_sef'] = 'Joomla SEF etkin';
$string['auth_joomla_joomla_sef_description'] = 'Joomla SEF ayarı. Yalnızca Joomla\'da çoklu dil etkinleştirildiğinde gereklidir';
$string['auth_joomla_joomla_user_groups'] = 'Joomla kullanıcı gruplarını kullanın';
$string['auth_joomla_joomla_user_groups_description'] = 'Öğrenciler ve öğretmenler için Joomla kullanıcı grupları oluşturun.';
$string['auth_joomla_logout_redirect_to_joomla'] = 'Moodle oturumu kapatıldığında Joomla\'ya yönlendir';
$string['auth_joomla_logout_redirect_to_joomla_description'] = 'Moodle oturumu kapatıldığında Joomla\'ya yönlendir';
$string['auth_joomla_logout_with_redirect'] = 'Yeniden yönlendirme ile çıkış kullan';
$string['auth_joomla_logout_with_redirect_description'] = 'Yalnızca alanlar arası ve "beni hatırla" kümesi için gereklidir';
$string['auth_joomla_redirectless_sso'] = 'Yönlendirmesiz TOA kullan';
$string['auth_joomla_redirectless_sso_description'] = 'Yeniden yönlendirme olmadan TOA kullanın. cURL gerektirir';
$string['auth_joomla_single_log_out'] = 'Tek çıkış';
$string['auth_joomla_single_log_out_description'] = 'Moodle\'dan çıkış yaparken Joomla\'dan çıkış yapın';
$string['auth_joomla_sync_to_joomla'] = 'Kullanıcıları Joomla ile senkronize edin';
$string['auth_joomla_sync_to_joomla_description'] = 'Yeni kullanıcıları ve profil güncellemelerini Joomla ile senkronize eder';
$string['auth_joomla_url'] = 'Joomla URL\'si<br>';
$string['auth_joomla_url_desc'] = 'Joomla sunucu URL\'si<br>';
$string['joomla_sp_description'] = 'Joomla Entegrasyonu için Hizmetler<br>';
$string['joomla_sp_name'] = 'Joomdle';
$string['pluginname'] = 'Joomdle';
