<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_course_contents', language 'tr', version '4.5'.
 *
 * @package     block_course_contents
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['config_autotitle_forced_off'] = 'Tüm bloklarda devre dışı';
$string['config_blocktitle_default'] = 'İçindekiler tablosu';
$string['config_display_course_link_forced_off'] = 'Tüm bloklarda devre dışı';
$string['config_enumerate_forced_off'] = 'Tüm bloklarda devre dışı';
$string['course_contents:addinstance'] = 'Yeni bir kurs içeriği bloğu ekleyin';
$string['pluginname'] = 'Kurs İçerikleri';
$string['privacy:metadata'] = 'Kurs içerikleri herhangi bir kişisel veri depolamaz';
